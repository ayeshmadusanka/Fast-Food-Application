import 'package:flutter/material.dart';
import 'menu.dart';

void main() {
  runApp(MaterialApp(
    home: CartPage(),
  ));
}

class CartPage extends StatefulWidget {
  @override
  _CartPageState createState() => _CartPageState();
}

class _CartPageState extends State<CartPage> {
  // List of cart items (with price, title, and quantity)
  List<CartItemData> cartItems = [
    CartItemData(imagePath: 'assets/zinger.jpg', title: 'Zinger Burger', price: 6.99, quantity: 1),

  ];

  // Function to calculate the total price
  double calculateTotal() {
    double total = 0;
    for (var item in cartItems) {
      total += item.price * item.quantity;
    }
    return total;
  }

  // Function to update quantity for a cart item
  void updateQuantity(int index, int change) {
    setState(() {
      cartItems[index].quantity += change;
      if (cartItems[index].quantity < 1) {
        cartItems[index].quantity = 1; // Prevent quantity from going below 1
      }
    });
  }

  // Function to remove an item from the cart
  void removeItem(int index) {
    setState(() {
      cartItems.removeAt(index);
    });
  }

  @override
  Widget build(BuildContext context) {
    double totalPrice = calculateTotal(); // Calculate the total price

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.close, color: Colors.orange.shade900),
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => MenuPage()),
            );
          },
        ),
        title: Text(
          'My Cart',
          style: TextStyle(color: Colors.orange.shade900),
        ),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            _buildFreeShippingBanner(),
            SizedBox(height: 16),
            Expanded(
              child: ListView.builder(
                itemCount: cartItems.length,
                itemBuilder: (context, index) {
                  return CartItem(
                    imagePath: cartItems[index].imagePath,
                    title: cartItems[index].title,
                    price: cartItems[index].price,
                    quantity: cartItems[index].quantity,
                    onRemove: () => removeItem(index),
                    onIncrease: () => updateQuantity(index, 1),
                    onDecrease: () => updateQuantity(index, -1),
                  );
                },
              ),
            ),
            Divider(thickness: 1),
            _buildTotalSection(totalPrice), // Pass the calculated total price
            SizedBox(height: 8),
            _buildCheckoutButton(),
            SizedBox(height: 8),
            _buildContinueShoppingButton(context),
          ],
        ),
      ),
    );
  }

  Widget _buildFreeShippingBanner() {
    return Container(
      padding: EdgeInsets.symmetric(vertical: 8.0),
      color: Colors.orange[50],
      width: double.infinity,
      child:Center(
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center, // Centers the row contents
          children: [
            Icon(
              Icons.card_giftcard_rounded, // Promo code icon
              color: Colors.orange.shade900,
              size: 24, // Adjust the size as needed
            ),
            SizedBox(width: 8), // Spacing between the icon and text
            Text(
              'APPLY YOUR PROMO CODE HERE',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                color: Colors.orange.shade900,
              ),
            ),
          ],
        ),
      )

    );
  }

  Widget _buildTotalSection(double totalPrice) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            'Total',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: Colors.orange.shade900,
            ),
          ),
          Text(
            '\$${totalPrice.toStringAsFixed(2)}', // Display the total with 2 decimal places
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: Colors.orange.shade900,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCheckoutButton() {
    return ElevatedButton(
      style: ElevatedButton.styleFrom(
        backgroundColor: Colors.orange.shade900,
        padding: EdgeInsets.symmetric(vertical: 15),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(30),
        ),
      ),
      onPressed: () {},
      child: Center(
        child: Text(
          'CHECK OUT',
          style: TextStyle(
            fontSize: 16,
            color: Colors.white,
          ),
        ),
      ),
    );
  }

  Widget _buildContinueShoppingButton(BuildContext context) {
    return TextButton(
      onPressed: () {
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => MenuPage()),
        );
      },
      child: Text(
        'CONTINUE SHOPPING',
        style: TextStyle(
          fontSize: 16,
          color: Colors.orange.shade900,
        ),
      ),
    );
  }
}

class CartItemData {
  final String imagePath;
  final String title;
  final double price;
  int quantity;

  CartItemData({
    required this.imagePath,
    required this.title,
    required this.price,
    required this.quantity,
  });
}

class CartItem extends StatelessWidget {
  final String imagePath;
  final String title;
  final double price;
  final int quantity;
  final VoidCallback onRemove;
  final VoidCallback onIncrease;
  final VoidCallback onDecrease;

  const CartItem({
    required this.imagePath,
    required this.title,
    required this.price,
    required this.quantity,
    required this.onRemove,
    required this.onIncrease,
    required this.onDecrease,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Stack(
        children: [
          Container(
            padding: EdgeInsets.all(16.0),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12.0),
              boxShadow: [
                BoxShadow(
                  color: Colors.grey.withOpacity(0.1),
                  blurRadius: 5.0,
                  spreadRadius: 1.0,
                ),
              ],
            ),
            child: Row(
              children: [
                Image.asset(
                  imagePath,
                  width: 80,
                  height: 80,
                  fit: BoxFit.cover,
                ),
                SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        title,
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 16,
                          color: Colors.orange.shade900,
                        ),
                      ),
                      SizedBox(height: 8),
                      Text(
                        '\$${price.toStringAsFixed(2)}',
                        style: TextStyle(
                          color: Colors.orange.shade900.withOpacity(0.7),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Positioned(
            top: 8,
            right: 8,
            child: IconButton(
              icon: Icon(Icons.cancel, color: Colors.orange.shade900),
              onPressed: onRemove,
            ),
          ),
          Positioned(
            bottom: 8,
            right: 8,
            child: Row(
              children: [
                IconButton(
                  icon: Icon(Icons.remove_circle, color: Colors.orange.shade900),
                  onPressed: onDecrease,
                ),
                Text('$quantity', style: TextStyle(color: Colors.orange.shade900)),
                IconButton(
                  icon: Icon(Icons.add_circle, color: Colors.orange.shade900),
                  onPressed: onIncrease,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
