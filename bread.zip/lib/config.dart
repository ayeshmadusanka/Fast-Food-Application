// config.dart
const String baseUrl = 'https://arogyahospital.online/bread/api';

const String imageUrl = 'https://arogyahospital.online/bread/';